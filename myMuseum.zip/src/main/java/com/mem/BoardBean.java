///////////////////////////////////////////////////////////////////////
//	2002.09.19 by CHAMBAB
//	Employee Table
//
//	public :
//		String getValue(String);
///////////////////////////////////////////////////////////////////////
package com.mem;

import java.io.*;
import java.io.Serializable;

public class BoardBean implements Serializable
{
	public String bt_id      = null;
	public String bb_step    = null;
	public String bb_id      = null;
	public String bb_type    = null;
	public String bb_ref     = null;
	public String bb_cur     = null;
	public String bb_level   = null;
	public String bb_title   = null;
	public String bb_content = null;
	public String bb_credate = null;
	public String bb_creater = null;
	public String bb_creid   = null;
	public String bb_email   = null;
	public String bb_attach  = null;
	public String bb_hit     = null;
	public String bb_msgtype = null;
}
