package com.mem;

import java.io.*;
import java.io.Serializable;

public class Message implements Serializable
{
	public String id = null;
	public String picture_id = null;
	public String message = null;
	public String writer = null;
	public String writernm = null;
}
