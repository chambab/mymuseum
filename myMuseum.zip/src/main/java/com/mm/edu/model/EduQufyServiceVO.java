package com.mm.edu.model;

/**
 * 
 * @author chambab
 *
 */

public class EduQufyServiceVO {

	private String welMbdId = null;
	private String welMbdIdeNo = null;
	private String welMbdNm = null;
	private String qufyId = null;
	private String qufyNm = null;
	private String servId = null;
	private String servNm = null;
	private String servStYmd = null;
	private String servEdYmd = null;
	public String getWelMbdId() {
		return welMbdId;
	}
	public void setWelMbdId(String welMbdId) {
		this.welMbdId = welMbdId;
	}
	public String getWelMbdIdeNo() {
		return welMbdIdeNo;
	}
	public void setWelMbdIdeNo(String welMbdIdeNo) {
		this.welMbdIdeNo = welMbdIdeNo;
	}
	public String getWelMbdNm() {
		return welMbdNm;
	}
	public void setWelMbdNm(String welMbdNm) {
		this.welMbdNm = welMbdNm;
	}
	public String getQufyId() {
		return qufyId;
	}
	public void setQufyId(String qufyId) {
		this.qufyId = qufyId;
	}
	public String getQufyNm() {
		return qufyNm;
	}
	public void setQufyNm(String qufyNm) {
		this.qufyNm = qufyNm;
	}
	public String getServId() {
		return servId;
	}
	public void setServId(String servId) {
		this.servId = servId;
	}
	public String getServNm() {
		return servNm;
	}
	public void setServNm(String servNm) {
		this.servNm = servNm;
	}
	public String getServStYmd() {
		return servStYmd;
	}
	public void setServStYmd(String servStYmd) {
		this.servStYmd = servStYmd;
	}
	public String getServEdYmd() {
		return servEdYmd;
	}
	public void setServEdYmd(String servEdYmd) {
		this.servEdYmd = servEdYmd;
	}
	
	
}
