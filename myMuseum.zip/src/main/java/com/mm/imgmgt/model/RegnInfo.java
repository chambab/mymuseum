package com.mm.imgmgt.model;

public class RegnInfo {

	private String regnInfId = null;
	private String latitude = null;
	private String longitude = null;
	private String compass = null;
	public String getRegnInfId() {
		return regnInfId;
	}
	public void setRegnInfId(String regnInfId) {
		this.regnInfId = regnInfId;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getCompass() {
		return compass;
	}
	public void setCompass(String compass) {
		this.compass = compass;
	}
	
	
	
}
