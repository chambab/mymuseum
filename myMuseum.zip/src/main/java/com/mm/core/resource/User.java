package com.mm.core.resource;

import java.util.ArrayList;

public class User {
	
	private String welMbdId;
	private String welMbdNm;
	private String welMbdEngStnNm;
	private String welMbdLarClCode;
	private String welMbdMidClCode;
	private String welMbdSmlCode;
	private String welMbdIdeNo;
	private String welMbdIdeSeqNo;
	private String critFamMbdId;
	private String siteAdmRegnCode;
	private String permAdmRegnCode;
	private String mbdStYmd;
	private String mbdEndYmd;
	private String mdbEndRsnCode;
	public String getWelMbdId() {
		return welMbdId;
	}
	public void setWelMbdId(String welMbdId) {
		this.welMbdId = welMbdId;
	}
	public String getWelMbdNm() {
		return welMbdNm;
	}
	public void setWelMbdNm(String welMbdNm) {
		this.welMbdNm = welMbdNm;
	}
	public String getWelMbdEngStnNm() {
		return welMbdEngStnNm;
	}
	public void setWelMbdEngStnNm(String welMbdEngStnNm) {
		this.welMbdEngStnNm = welMbdEngStnNm;
	}
	public String getWelMbdLarClCode() {
		return welMbdLarClCode;
	}
	public void setWelMbdLarClCode(String welMbdLarClCode) {
		this.welMbdLarClCode = welMbdLarClCode;
	}
	public String getWelMbdMidClCode() {
		return welMbdMidClCode;
	}
	public void setWelMbdMidClCode(String welMbdMidClCode) {
		this.welMbdMidClCode = welMbdMidClCode;
	}
	public String getWelMbdSmlCode() {
		return welMbdSmlCode;
	}
	public void setWelMbdSmlCode(String welMbdSmlCode) {
		this.welMbdSmlCode = welMbdSmlCode;
	}
	public String getWelMbdIdeNo() {
		return welMbdIdeNo;
	}
	public void setWelMbdIdeNo(String welMbdIdeNo) {
		this.welMbdIdeNo = welMbdIdeNo;
	}
	public String getWelMbdIdeSeqNo() {
		return welMbdIdeSeqNo;
	}
	public void setWelMbdIdeSeqNo(String welMbdIdeSeqNo) {
		this.welMbdIdeSeqNo = welMbdIdeSeqNo;
	}
	public String getCritFamMbdId() {
		return critFamMbdId;
	}
	public void setCritFamMbdId(String critFamMbdId) {
		this.critFamMbdId = critFamMbdId;
	}
	public String getSiteAdmRegnCode() {
		return siteAdmRegnCode;
	}
	public void setSiteAdmRegnCode(String siteAdmRegnCode) {
		this.siteAdmRegnCode = siteAdmRegnCode;
	}
	public String getPermAdmRegnCode() {
		return permAdmRegnCode;
	}
	public void setPermAdmRegnCode(String permAdmRegnCode) {
		this.permAdmRegnCode = permAdmRegnCode;
	}
	public String getMbdStYmd() {
		return mbdStYmd;
	}
	public void setMbdStYmd(String mbdStYmd) {
		this.mbdStYmd = mbdStYmd;
	}
	public String getMbdEndYmd() {
		return mbdEndYmd;
	}
	public void setMbdEndYmd(String mbdEndYmd) {
		this.mbdEndYmd = mbdEndYmd;
	}
	public String getMdbEndRsnCode() {
		return mdbEndRsnCode;
	}
	public void setMdbEndRsnCode(String mdbEndRsnCode) {
		this.mdbEndRsnCode = mdbEndRsnCode;
	}
	
	

}
