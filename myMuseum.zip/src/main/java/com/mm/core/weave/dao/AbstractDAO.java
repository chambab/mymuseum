package com.mm.core.weave.dao;

public abstract class AbstractDAO {

}
