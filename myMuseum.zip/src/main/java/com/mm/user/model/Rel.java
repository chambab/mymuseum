package com.mm.user.model;

public class Rel {

	private String mstUserId = null;
	private String subUserId = null;
	private String regDt = null;
	public String getMstUserId() {
		return mstUserId;
	}
	public void setMstUserId(String mstUserId) {
		this.mstUserId = mstUserId;
	}
	public String getSubUserId() {
		return subUserId;
	}
	public void setSubUserId(String subUserId) {
		this.subUserId = subUserId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	
	
}
